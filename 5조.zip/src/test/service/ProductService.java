package test.service;

import java.util.ArrayList;

import test.dao.ProductDAO;
import test.vo.Product;

public class ProductService {
	private static ProductService service=new ProductService();
	
	public ProductDAO dao=ProductDAO.getInstance();
	
	private ProductService() {}
	public static ProductService getInstance() {
		return service;
	}
	public ArrayList<Product> productSearchList(String pid,int month){
		return dao.productSearchList(pid,month);
	}
	public Product productSearch(String pid) {
		return dao.productSearch(pid);
	}
	/*public ArrayList<Product> productList(){
		return dao.productList();
	}
	public Product productSearch(String pid) {
		return dao.productSearch(pid);
	}*/
	public void productCountUpdate(int count,String pid) {
		dao.productCountUpdate(count,pid);
	}
	public void productPlusCountUpdate(int count,String pid) {
		dao.productPlusCountUpdate(count,pid);
	}

}