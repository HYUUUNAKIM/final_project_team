package test.service;

import java.util.ArrayList;

import test.dao.OrdersDAO;
import test.vo.*;

public class OrdersService {
	private static OrdersService service=new OrdersService();
	
	public OrdersDAO dao=OrdersDAO.getInstance();
	
	private OrdersService() {}
	public static OrdersService getInstance() {
		return service;
	}
	public void ordersInsert(Orders order) {
		dao.ordersInsert(order);
	}
	public ArrayList<Orders> orderList(String id){
		return dao.orderList(id);
	}
	public ArrayList<Orders> totalorderList(){
		return dao.totalorderList();
	}
	public ArrayList<Orders> orderDeleteSearchList(String id){
		return dao.orderDeleteSearchList(id);
	}
	public void stateUpdate(int oid) {
		dao.stateUpdate(oid);
	}
	public void orderDelete(int oid) {
		dao.orderDelete(oid);
	}
	public boolean orderSearch(String id) {
		return dao.orderSearch(id);
	}
	public Orders ordercountSearch(int oid) {
		return dao.ordercountSearch(oid);
	}
}