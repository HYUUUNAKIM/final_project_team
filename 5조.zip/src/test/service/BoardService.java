package test.service;

import java.util.ArrayList;

import test.dao.BoardDAO;
import test.vo.Basket;
import test.vo.Board;
import test.vo.Member;

public class BoardService {
	private static BoardService service=new BoardService();
	
	public BoardDAO dao=BoardDAO.getInstance();
	
	private BoardService() {}
	public static BoardService getInstance() {
		return service;
	}
	public void boardInsert(Board board) {
		dao.boardInsert(board);
	}
	public ArrayList<Board> boardList(){
		return dao.boardList();
	}
	public Board boardSearch(int boid) {
		return dao.boardSearch(boid);
	}
	public void boardDelete(int boid) {
		dao.boardDelete(boid);
	}
	public void boardUpdate(Board board) {
		dao.boardUpdate(board);
	}
}
