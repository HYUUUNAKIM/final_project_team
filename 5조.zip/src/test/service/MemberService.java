package test.service;

import java.util.ArrayList;

import test.dao.MemberDAO;
import test.vo.*;

public class MemberService {
	private static MemberService service=new MemberService();
	
	public MemberDAO dao=MemberDAO.getInstance();
	
	private MemberService() {}
	public static MemberService getInstance() {
		return service;
	}
	public void memberInsert(Member member) {
		dao.memberInsert(member);
	}
	public boolean IdCheck(String id) {
		return dao.IdCheck(id);
	}
	public Member memberSearch(String id) {
		return dao.memberSearch(id);
	}
	public void cuponInsert(String id,String cid) {
		 dao.cuponInsert(id,cid);
	}
	public void cuponDelete(String id) {
		 dao.cuponDelete(id);
	}
	public void memberUpdate(Member member) {
		 dao.memberUpdate(member);
	}
	public void memberDelete(String id) {
		dao.memberDelete(id);
	}
	public ArrayList<Member> memberList(){
		return dao.memberList();
	}
	public String IdSearch(String name,String phonenum) {
		return dao.IdSearch(name,phonenum);
	}
}