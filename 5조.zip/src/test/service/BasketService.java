package test.service;

import java.util.ArrayList;

import test.dao.BasketDAO;
import test.vo.*;

public class BasketService {
	private static BasketService service=new BasketService();
	
	public BasketDAO dao=BasketDAO.getInstance();
	
	private BasketService() {}
	public static BasketService getInstance() {
		return service;
	}
	public void basketInsert(Basket basket) {
		dao.basketInsert(basket);
	}
	public ArrayList<Basket> basketList(String id){
		return dao.basketList(id);
	}
	public Basket basketSearch(int bid){
		return dao.basketSearch(bid);
	}
	public void basketDelete(int bid) {
		dao.basketDelete(bid);
	}
}
