package test.vo;

public class Board {
	private String id;
	private String content;
	private String title;
	private int boid;
	public int getBoid() {
		return boid;
	}
	public void setBoid(int boid) {
		this.boid = boid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
}
