package test.vo;

public class Product {
	private String pid;
	private int price;
	private int pcount;
	private String pname;
	private int pmonth;
	private String pdate;
	public int getPmonth() {
		return pmonth;
	}
	public void setPmonth(int pmonth) {
		this.pmonth = pmonth;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPcount() {
		return pcount;
	}
	public void setPcount(int pcount) {
		this.pcount = pcount;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	
}
