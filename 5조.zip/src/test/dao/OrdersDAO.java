package test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import test.vo.*;

public class OrdersDAO {

private static OrdersDAO ordersDao=new OrdersDAO();
	
	private OrdersDAO() {}
	
	public static OrdersDAO getInstance()
	{
		return ordersDao;
	}
	public Connection connect() {
		Connection conn=null;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=UTC", "root", "cs1234");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	public void ordersInsert(Orders order) {
		try {
		Connection con=this.connect();
		PreparedStatement pstmt=con.prepareStatement("insert into orders(id,pid,ocount,odate,total,payment) values(?,?,?,sysdate(),?,?)");
		pstmt.setString(1, order.getId());
		pstmt.setString(2, order.getPid());
		pstmt.setInt(3, order.getOcount());
		pstmt.setInt(4, order.getTotal());
		pstmt.setString(5, order.getPayment());
		pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Orders> orderList(String id){
		ArrayList<Orders> orderlist=new ArrayList<Orders>();
		Orders order=null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select pname,pdate,orders.* from orders,product where product.pid=orders.pid and id=?");
		pstmt.setString(1,id);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			order=new Orders();
			order.setPname(rs.getString(1));
			order.setPdate(rs.getString(2));
			order.setOid(Integer.parseInt(rs.getString(3)));
			order.setId(rs.getString(4));
			order.setPid(rs.getString(5));
			order.setOcount(Integer.parseInt(rs.getString(6)));
			order.setOdate(rs.getString(7));
			order.setTotal(Integer.parseInt(rs.getString(8)));
			order.setPayment(rs.getString(9));
			order.setState(rs.getString(10));
			orderlist.add(order);
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return orderlist;
	}
	public ArrayList<Orders> orderDeleteSearchList(String id){
		ArrayList<Orders> orderlist=new ArrayList<Orders>();
		Orders order=null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select pname,pdate,orders.* from orders,product where product.pid=orders.pid and id=? and state='drop'");
		pstmt.setString(1,id);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			order=new Orders();
			order.setPname(rs.getString(1));
			order.setPdate(rs.getString(2));
			order.setOid(Integer.parseInt(rs.getString(3)));
			order.setId(rs.getString(4));
			order.setPid(rs.getString(5));
			order.setOcount(Integer.parseInt(rs.getString(6)));
			order.setOdate(rs.getString(7));
			order.setTotal(Integer.parseInt(rs.getString(8)));
			order.setPayment(rs.getString(9));
			orderlist.add(order);
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return orderlist;
	}
	public ArrayList<Orders> totalorderList(){
		ArrayList<Orders> orderlist=new ArrayList<Orders>();
		Orders order=null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select *from orders");
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			order=new Orders();
			order.setOid(Integer.parseInt(rs.getString(1)));
			order.setId(rs.getString(2));
			order.setPid(rs.getString(3));
			order.setOcount(Integer.parseInt(rs.getString(4)));
			order.setOdate(rs.getString(5));
			order.setTotal(Integer.parseInt(rs.getString(6)));
			order.setPayment(rs.getString(7));
			order.setState(rs.getString(8));
			orderlist.add(order);
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return orderlist;
	}
	public void stateUpdate(int oid) {
		try {
			Connection con=this.connect();
			PreparedStatement pstmt=con.prepareStatement("update orders set state=? where oid=?");
			pstmt.setInt(2, oid);
			pstmt.setString(1, "drop");
			
			pstmt.executeUpdate();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
	public void orderDelete(int oid) {
		try {
			Connection con=this.connect();
			PreparedStatement pstmt=con.prepareStatement("delete from orders where oid=?");
			pstmt.setInt(1, oid);
			
			pstmt.executeUpdate();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
	public boolean orderSearch(String id) {
		boolean result=false;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select id from orders where id=?");
		pstmt.setString(1, id);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			result=true;//아이디가 있을 때
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return result;//아이디가 없을 때
	}
	public Orders ordercountSearch(int oid) {
		Orders order = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select *from orders where oid=?");
		pstmt.setInt(1, oid);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			order=new Orders();
			order.setOid(Integer.parseInt(rs.getString(1)));
			order.setId(rs.getString(2));
			order.setPid(rs.getString(3));
			order.setOcount(Integer.parseInt(rs.getString(4)));
			order.setOdate(rs.getString(5));
			order.setTotal(Integer.parseInt(rs.getString(6)));
			order.setPayment(rs.getString(7));
			//order.setState(rs.getString(8));
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return order;
	}
}