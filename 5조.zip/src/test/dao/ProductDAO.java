package test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import test.vo.Member;
import test.vo.Product;

public class ProductDAO {

private static ProductDAO productDao=new ProductDAO();
	
	private ProductDAO() {}
	
	public static ProductDAO getInstance()
	{
		return productDao;
	}
	public Connection connect() {
		Connection conn=null;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=UTC", "root", "cs1234");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	public ArrayList<Product> productSearchList(String pid,int month){
		ArrayList<Product> list=new ArrayList<Product>();
		Product product = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select * from product where pid like ? and pmonth=?");
		pstmt.setString(1, pid);
		pstmt.setInt(2, month);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			product=new Product();
			product.setPid(rs.getString(1));
			product.setPrice(Integer.parseInt(rs.getString(2)));
			product.setPcount(Integer.parseInt(rs.getString(3)));
			product.setPmonth(Integer.parseInt(rs.getString(4)));
			product.setPdate(rs.getString(5));
			product.setPname(rs.getString(6));
			list.add(product);
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public Product productSearch(String pid) {
		Product product = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select * from product where pid=?");
		pstmt.setString(1, pid);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			product=new Product();
			product.setPid(rs.getString(1));
			product.setPrice(Integer.parseInt(rs.getString(2)));
			product.setPcount(Integer.parseInt(rs.getString(3)));
			product.setPmonth(Integer.parseInt(rs.getString(4)));
			product.setPdate(rs.getString(5));
			product.setPname(rs.getString(6));
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return product;
	}
	public void productCountUpdate(int count,String pid)
	{
		try {
			Connection con = connect();
			PreparedStatement pstmt = con.prepareStatement("select pcount from product where pid = ?");
			pstmt.setString(1, pid);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {

				int num = Integer.parseInt(rs.getString(1));
				num -= count;
				
				pstmt = con.prepareStatement("update product set pcount=? where pid = ?");
				pstmt.setInt(1, num);
				pstmt.setString(2, pid);
				pstmt.executeUpdate();
						
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void productPlusCountUpdate(int count,String pid)
	{
		try {
			Connection con = connect();
			PreparedStatement pstmt = con.prepareStatement("select pcount from product where pid = ?");
			pstmt.setString(1, pid);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {

				int num = Integer.parseInt(rs.getString(1));
				num += count;
				
				pstmt = con.prepareStatement("update product set pcount=? where pid = ?");
				pstmt.setInt(1, num);
				pstmt.setString(2, pid);
				pstmt.executeUpdate();
						
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
