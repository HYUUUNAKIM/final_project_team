package test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import test.vo.*;

public class BoardDAO{
	private static BoardDAO boardDao=new BoardDAO();
	
	private BoardDAO() {}

	public static BoardDAO getInstance() {
		// TODO Auto-generated method stub
		return boardDao;
	}
	public Connection connect() {
		Connection conn=null;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=UTC", "root", "cs1234");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	public void boardInsert(Board board) {
		try {
		Connection con=this.connect();
		PreparedStatement pstmt=con.prepareStatement("insert into board(id,content,title) values(?,?,?)");
		pstmt.setString(1, board.getId());
		pstmt.setString(2, board.getContent());
		pstmt.setString(3, board.getTitle());
		
		pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Board> boardList(){
		ArrayList<Board> list=new ArrayList<Board>();
		Board board = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select * from board");
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			board=new Board();
			board.setBoid(Integer.parseInt(rs.getString(1)));
			board.setId(rs.getString(2));
			board.setContent(rs.getString(3));
			board.setTitle(rs.getString(4));
			list.add(board);
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public Board boardSearch(int boid) {
		Board board = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select * from board where boid=?");
		pstmt.setInt(1, boid);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			board=new Board();
			board.setBoid(Integer.parseInt(rs.getString(1)));
			board.setId(rs.getString(2));
			board.setContent(rs.getString(3));
			board.setTitle(rs.getString(4));
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return board;
	}
	public void boardUpdate(Board board)
	{
		try {
			Connection con = this.connect();
			PreparedStatement pstmt = con.prepareStatement("update board set id=?,content=?,title=? where boid=?");
			pstmt.setString(1, board.getId());
			pstmt.setString(2,board.getContent());
			pstmt.setString(3, board.getTitle());
			pstmt.setInt(4, board.getBoid());
			
			pstmt.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void boardDelete(int boid) {
		try {
			Connection con=this.connect();
			PreparedStatement pstmt=con.prepareStatement("delete from board where boid=?");
			pstmt.setInt(1, boid);
			
			pstmt.executeUpdate();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
}
