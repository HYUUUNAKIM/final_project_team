package test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import test.vo.Member;

public class MemberDAO {
	private static MemberDAO MemberDao=new MemberDAO();
	
	private MemberDAO() {}

	public static MemberDAO getInstance() {
		// TODO Auto-generated method stub
		return MemberDao;
	}
	public Connection connect() {
		Connection conn=null;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=UTC", "root", "cs1234");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	public boolean IdCheck(String id) {
		boolean result=false;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select id from member where id=?");
		pstmt.setString(1, id);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			result=true;//아이디가 있을 때
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return result;//아이디가 없을 때
	}
	public Member memberSearch(String id) {
		Member member = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select * from member where id=?");
		pstmt.setString(1, id);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			member=new Member();
			member.setId(rs.getString(1));
			member.setPasswd((rs.getString(2)));
			member.setName(rs.getString(3));
			member.setPhone(rs.getString(4));
			member.setMail(rs.getString(5));
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return member;
	}
	public void cuponInsert(String id,String cid) {
		try {
			Connection con=this.connect();
			PreparedStatement pstmt=con.prepareStatement("update member set cid=? where id=?");
			pstmt.setString(2, id);
			pstmt.setString(1, cid);
			
			pstmt.executeUpdate();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
	public void cuponDelete(String id) {
		try {
			Connection con=this.connect();
			PreparedStatement pstmt=con.prepareStatement("update member set cid=? where id=?");
			pstmt.setString(2, id);
			pstmt.setString(1, null);
			
			pstmt.executeUpdate();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
	public void memberInsert(Member member) {
		try {
		Connection con=this.connect();
		PreparedStatement pstmt=con.prepareStatement("insert into member(id, passwd, name, phone ,mail) values(?,?,?,?,?)");
		pstmt.setString(1, member.getId());
		pstmt.setString(2, member.getPasswd());
		pstmt.setString(3, member.getName());
		pstmt.setString(4, member.getPhone());
		pstmt.setString(5, member.getMail());
		
		pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void memberDelete(String id) {
		try {
		Connection con=this.connect();
		PreparedStatement pstmt=con.prepareStatement("delete from member where id=?");
		pstmt.setString(1, id);
		pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Member> memberList(){
		ArrayList<Member> list=new ArrayList<Member>();
		Member member = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select * from member");
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			member=new Member();
			member.setId(rs.getString(1));
			member.setPasswd((rs.getString(2)));
			member.setName(rs.getString(3));
			member.setPhone(rs.getString(4));
			member.setMail(rs.getString(5));
			list.add(member);
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public String IdSearch(String name,String phonenum) {
		String result=null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select * from member where name=? and phone=? ");
		pstmt.setString(1, name);
		pstmt.setString(2, phonenum);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			result=rs.getString(1);
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public void memberUpdate(Member member) {
		try {
			Connection con=this.connect();
			PreparedStatement pstmt=con.prepareStatement("update member set passwd=?,name=?, phone=?,mail=? where id=?");
			pstmt.setString(5, member.getId());
			pstmt.setString(1, member.getPasswd());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getPhone());
			pstmt.setString(4, member.getMail());
			
			pstmt.executeUpdate();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
}
