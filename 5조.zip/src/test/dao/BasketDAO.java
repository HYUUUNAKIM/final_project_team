package test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import test.vo.*;

public class BasketDAO {

private static BasketDAO basketDao=new BasketDAO();
	
	private BasketDAO() {}
	
	public static BasketDAO getInstance()
	{
		return basketDao;
	}
	public Connection connect() {
		Connection conn=null;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=UTC", "root", "cs1234");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	public void basketInsert(Basket basket) {
		try {
		Connection con=this.connect();
		PreparedStatement pstmt=con.prepareStatement("insert into basket(id,pid,pname,ocount,total) values(?,?,?,?,?)");
		pstmt.setString(1, basket.getId());
		pstmt.setString(2, basket.getPid());
		pstmt.setString(3, basket.getPname());
		pstmt.setInt(4, basket.getOcount());
		pstmt.setInt(5, basket.getTotal());
		
		pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Basket> basketList(String id){
		ArrayList<Basket> list=new ArrayList<Basket>();
		Basket basket = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select *from basket where id=?");
		pstmt.setString(1,id);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			basket=new Basket();
			basket.setBid(Integer.parseInt(rs.getString(1)));
			basket.setId(rs.getString(2));
			basket.setPid(rs.getString(3));
			basket.setPname(rs.getString(4));
			basket.setOcount(Integer.parseInt(rs.getString(5)));
			basket.setTotal(Integer.parseInt(rs.getString(6)));
			list.add(basket);
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public Basket basketSearch(int bid) {
		Basket basket = null;
		try {
		Connection con=connect();
		PreparedStatement pstmt=con.prepareStatement("select *from basket where bid=?");
		pstmt.setInt(1, bid);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			basket=new Basket();
			basket.setBid(Integer.parseInt(rs.getString(1)));
			basket.setId(rs.getString(2));
			basket.setPid(rs.getString(3));
			basket.setPname(rs.getString(4));
			basket.setOcount(Integer.parseInt(rs.getString(5)));
			basket.setTotal(Integer.parseInt(rs.getString(6)));
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return basket;
	}
	public void basketDelete(int bid) {
		try {
			Connection con=this.connect();
			PreparedStatement pstmt=con.prepareStatement("delete from basket where bid=?");
			pstmt.setInt(1, bid);
			
			pstmt.executeUpdate();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
}