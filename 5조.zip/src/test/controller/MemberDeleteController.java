package test.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.MemberService;
import test.service.OrdersService;

public class MemberDeleteController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=req.getSession();
		String id=(String)session.getAttribute("loginID");
		
		OrdersService service=OrdersService.getInstance();
		boolean result=service.orderSearch(id);
		
		if(result==true) {
			req.setAttribute("dropFail", "a");
			HttpUtil.forward(req, resp, "mypage.jsp");
		}
		else {
			MemberService ser=MemberService.getInstance();
			ser.memberDelete(id);
			HttpUtil.forward(req, resp, "logout.jsp");
		}
	}

}
