package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.service.MemberService;
import test.vo.Member;

public class IdSearchController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
	
		String name=req.getParameter("name");
		String phonenum=req.getParameter("phonenum");
		
		if(name.isEmpty()||phonenum.isEmpty()) {
			req.setAttribute("error", "error");
			HttpUtil.forward(req, resp, "idSearch.jsp");
			return;
		}
		
		MemberService service=MemberService.getInstance();
		String id=service.IdSearch(name,phonenum);
		
		req.setAttribute("searchid", id);
		HttpUtil.forward(req, resp, "/result/idSearchOutput.jsp");

	}
}
