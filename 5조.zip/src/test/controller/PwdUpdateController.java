package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.MemberService;
import test.vo.*;

public class PwdUpdateController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=req.getSession();
		String password=req.getParameter("pwd");
		
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		Member m=new Member();
		m=(Member)session.getAttribute("member");
		Member member=new Member();
		member.setId(m.getId());
		member.setPasswd(password);
		member.setName(m.getName());
		member.setPhone(m.getPhone());
		member.setMail(m.getMail());
		
		MemberService service=MemberService.getInstance();
		service.memberUpdate(member);
		
		session.invalidate();
		HttpUtil.forward(req, resp, "login.jsp");
	}

}
