package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.BasketService;

public class BasketDeleteController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession();
		String[] bid1 =(String[])req.getParameterValues("bid");
		BasketService se=BasketService.getInstance();
		
		int[] bid=new int[bid1.length];
		
		for(int i=0; i < bid1.length; i++){
			bid[i]=Integer.parseInt(bid1[i]);
			se.basketDelete(bid[i]);
		}
		HttpUtil.forward(req, resp, "index.jsp");
	}

}
