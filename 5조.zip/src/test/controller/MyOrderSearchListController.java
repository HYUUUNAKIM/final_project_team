package test.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.OrdersService;
import test.service.ProductService;
import test.vo.*;

public class MyOrderSearchListController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=req.getSession();
		
		String id=(String)session.getAttribute("loginID");

		ArrayList<Orders> orderlist=OrdersService.getInstance().orderList(id);
		
		req.setAttribute("orderlist", orderlist);
		HttpUtil.forward(req, resp, "/result/myOrderListOutput.jsp");
	}

}
