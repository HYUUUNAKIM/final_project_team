package test.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.service.OrdersService;
import test.vo.*;

public class TotalOrderListController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Orders> orderlist=OrdersService.getInstance().totalorderList();
		
		req.setAttribute("totalorderlist", orderlist);
		HttpUtil.forward(req, resp, "/result/totalorderListOutput.jsp");
	}

}
