package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.MemberService;
import test.vo.*;

public class ImformationController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession();
		String id=(String)session.getAttribute("loginID");
		
		MemberService service=MemberService.getInstance();
		Member member=service.memberSearch(id);
		session.setAttribute("memberif", member);
		HttpUtil.forward(req, resp, "/result/imformation.jsp");
	}
}
