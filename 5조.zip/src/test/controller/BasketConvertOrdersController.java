package test.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.BasketService;
import test.service.OrdersService;
import test.service.ProductService;
import test.vo.*;

public class BasketConvertOrdersController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession();
		String[] bid1 =(String[])req.getParameterValues("bid");
		int[] bid=new int[bid1.length];
		ArrayList<Product> list=new ArrayList<Product>();
		ArrayList<Basket> list2=new ArrayList<Basket>();
		
		for(int i=0; i < bid1.length; i++){
			bid[i]=Integer.parseInt(bid1[i]);
			BasketService service=BasketService.getInstance();
			Basket basket=new Basket();
			basket=service.basketSearch(bid[i]);
			ProductService ser=ProductService.getInstance();
			Product product=new Product();
			product=ser.productSearch(basket.getPid());
			list.add(product);
			list2.add(basket);
		}
		req.setAttribute("basketproductlist", list);
		req.setAttribute("basketlist", list2);
		HttpUtil.forward(req, resp, "buyBasket.jsp");
	}
}
