package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.OrdersService;
import test.service.ProductService;
import test.vo.*;

public class OrderDeleteController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession();
		String[] oid1 =(String[])req.getParameterValues("oid");
		int[] oid=new int[oid1.length];
		
		for(int i=0; i < oid1.length; i++){
			oid[i]=Integer.parseInt(oid1[i]);
			OrdersService service=OrdersService.getInstance();
			ProductService ser=ProductService.getInstance();
			Orders order=new Orders();
			Product product=new Product();
			order=service.ordercountSearch(oid[i]);
			product=ser.productSearch(order.getPid());
			service.orderDelete(oid[i]);
			ser.productPlusCountUpdate(order.getOcount(), order.getPid());
		}
		HttpUtil.forward(req, resp, "admin.jsp");

	}

}
