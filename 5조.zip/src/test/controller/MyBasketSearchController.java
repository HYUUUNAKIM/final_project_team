package test.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.BasketService;
import test.vo.Basket;

public class MyBasketSearchController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
HttpSession session=req.getSession();
		
		String id=(String)session.getAttribute("loginID");

		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		ArrayList<Basket> basketlist=BasketService.getInstance().basketList(id);
		req.setAttribute("basketlist", basketlist);
		HttpUtil.forward(req, resp, "/result/basketListOutput.jsp");
	}

}
