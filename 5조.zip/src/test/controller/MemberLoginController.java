package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.MemberService;
import test.vo.Member;

public class MemberLoginController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=req.getSession();
		String id=req.getParameter("id");
		String pwd=req.getParameter("pwd");
		
		MemberService service=MemberService.getInstance();
		Member searchMember=service.memberSearch(id);
				
		resp.setContentType("text/html;charset=UTF-8");
		//PrintWriter out=resp.getWriter();
		
		if(searchMember!=null) {//id o
			if(id.equals(searchMember.getId())&&pwd.equals(searchMember.getPasswd())) {
				//login o
				if (id.equals("admin")&&pwd.equals("1234")) {
					session.setAttribute("loginID", id);
					HttpUtil.forward(req, resp, "admin.jsp");//관리자 페이지로
					return;
				}
				req.setAttribute("success", "a");
				session.setAttribute("loginID", id);
				session.setAttribute("memberif", searchMember);
				HttpUtil.forward(req, resp, "loginMain.jsp");
				return;
			}
			else if(id.equals(searchMember.getId())&&!pwd.equals(searchMember.getPasswd())) {
				//pwd x
				session.invalidate();
				req.setAttribute("passfail","비밀번호가 틀렸습니다.");
				HttpUtil.forward(req, resp, "login.jsp");
				return;
				}
		}
		//id x
		req.setAttribute("idfail", "아이디가 존재하지 않습니다.");
		HttpUtil.forward(req, resp, "login.jsp");
		
		
	}
}
