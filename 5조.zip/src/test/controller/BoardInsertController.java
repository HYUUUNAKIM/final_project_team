package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.BoardService;
import test.vo.Board;

public class BoardInsertController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession();
		String id=req.getParameter("id");
		String content=req.getParameter("content");
		String title=req.getParameter("title");
		
		Board board=new Board();
		board.setId(id);
		board.setContent(content);
		board.setTitle(title);
		
		BoardService service=BoardService.getInstance();
		service.boardInsert(board);
		HttpUtil.forward(req, resp, "index.jsp");
	}

}
