package test.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.BasketService;
import test.vo.*;

public class BasketInsertController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    resp.setContentType("text/html;charset=UTF-8");
	    PrintWriter out=resp.getWriter();
	    HttpSession session=req.getSession();
	     
		ArrayList<Product> list=(ArrayList<Product>) session.getAttribute("list");
		int people=Integer.parseInt(req.getParameter("people"));
		int num=Integer.parseInt(req.getParameter("num"));
		String id=(String)session.getAttribute("loginID");
		Product product=list.get(num);
		Basket basket=new Basket();
		
	    basket.setId(id);
	    basket.setPid(product.getPid());
	    basket.setOcount(people);
	    basket.setPname(product.getPname());
	    int total=product.getPrice()*people;
	    basket.setTotal(total);
	    
	    BasketService service=BasketService.getInstance();
	    service.basketInsert(basket);
	    //구매가 되었을 떄 alert창으로 찜하기가 되었습니다라고 뜨게
	    HttpUtil.forward(req, resp, "index.jsp");
	}

}
