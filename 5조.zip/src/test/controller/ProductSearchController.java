package test.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.ProductService;
import test.vo.Product;

public class ProductSearchController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	      resp.setContentType("text/html;charset=UTF-8");
	      PrintWriter out=resp.getWriter();
	      HttpSession session=req.getSession();
	      
	      String pid1=req.getParameter("pid");
	      int month=Integer.parseInt(req.getParameter("month"));
	      
	      String pid=pid1+"%";
	     
	      ArrayList<Product> list=ProductService.getInstance().productSearchList(pid,month);
	      req.setAttribute("list", list);
	      HttpUtil.forward(req, resp, "/result/searchlist.jsp");
	      

	}

}
