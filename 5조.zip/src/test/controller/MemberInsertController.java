package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.MemberService;
import test.vo.Member;

public class MemberInsertController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession();

		String id=req.getParameter("id");
		String pwd=req.getParameter("passwd");
		String name=req.getParameter("name");
		String phone=req.getParameter("phone");
		String mail=req.getParameter("mail");
		
		String inputid=(String)session.getAttribute("outputid");
		
		if(pwd.isEmpty()||name.isEmpty()||mail.isEmpty()||phone.isEmpty()) {
			req.setAttribute("InputId", inputid);//그냥 넣어둔 값
			req.setAttribute("error", "Fill every part!!!!");
			HttpUtil.forward(req, resp, "/register.jsp");
			return;
		}
		
		Member member=new Member();
		member.setId(id);
		member.setPasswd(pwd);
		member.setName(name);
		member.setMail(mail);
		member.setPhone(phone);
		
		//service 객체
		MemberService service=MemberService.getInstance();
		service.memberInsert(member);
		//output
		session.invalidate();
		HttpUtil.forward(req, resp, "index.jsp");
	}

}
