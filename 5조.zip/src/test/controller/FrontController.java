package test.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FrontController extends HttpServlet{
	
	HashMap<String,Controller> list = null;
	public void init(ServletConfig config)throws ServletException{
		list=new HashMap<String, Controller>();
		list.put("/memberInsert.do", new MemberInsertController());
		list.put("/idSearch.do", new IdSearchController());
		list.put("/basketInsert.do", new BasketInsertController());
		list.put("/myOrderSearch.do", new MyOrderSearchListController());
		list.put("/basketdelete.do", new BasketDeleteController());
		list.put("/totalorderlist.do", new TotalOrderListController());
		list.put("/memberUpdate.do", new MemberUpdateController());
		list.put("/memberList.do", new MemberListController());
		//list.put("/productList.do", new ProductListController());
		list.put("/imformation.do", new ImformationController());
		list.put("/basketConvertOrders.do", new BasketConvertOrdersController());
		list.put("/memberDelete.do", new MemberDeleteController());
		list.put("/memberSearch.do", new MemberSearchController());
		list.put("/orderDelete.do", new OrderDeleteController());
		list.put("/orderDeleteUpdate.do", new OrderDeleteUpdateController());
		list.put("/orderDeleteSearch.do", new OrderDeleteSearchController());
		list.put("/orderInsert.do", new OrderInsertController());
		list.put("/orderInsertbasket.do", new OrderInsertBasketController());
		list.put("/memberLogin.do", new MemberLoginController());
		list.put("/productSearch.do", new ProductSearchController());
		list.put("/mybasketSearch.do", new MyBasketSearchController());
		list.put("/boardInsert.do", new BoardInsertController());
		list.put("/boardSearchlist.do", new BoardSearchListController());
		list.put("/listSearch.do", new ListSearchController());
		list.put("/boardUpdate.do", new BoardUpdateController());
		list.put("/pwdUpdate.do", new PwdUpdateController());
		list.put("/boardlistDelete.do", new BoardListDeleteController());



	}
	public void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
	{
		String uri=req.getRequestURI();
		String cp=req.getContextPath();
		String path=uri.substring(cp.length(),uri.length());
		
		Controller sc=list.get(path);
		sc.execute(req, resp);
	}
}