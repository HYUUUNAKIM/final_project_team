package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.MemberService;
import test.vo.Member;

public class MemberSearchController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=req.getSession();
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		String path=null;
		String word=req.getParameter("word");
		String id=req.getParameter("id");
		
		if(word.equals("pwdsearch")) {
			path="pwdSearch.jsp";
		}
		else if(word.equals("idcheck")) {
			path="register.jsp";
		}
		if(id.isEmpty()) {
			req.setAttribute("input", "아이디를 입력하세요");
			HttpUtil.forward(req, resp, path);
			return;
		}

		
		MemberService service=MemberService.getInstance();
		boolean check=service.IdCheck(id);//아이디 중복체크검사
		
		if(check==true) {
			//db에 존재하는 아이디(=중복)
			req.setAttribute("msg", "이미있는 아이디입니다.");
			Member searchMember=service.memberSearch(id);
			req.setAttribute("check", check);
			req.setAttribute("member", searchMember);
			if(word.equals("idcheck")) {
				HttpUtil.forward(req, resp, "register.jsp");
				return;
			}
		}
		else {
			//db에 존재하지 않는 아이디(=중복하지 않는 아이디 회원가입 가능)
			req.setAttribute("error", "사용가능한 아이디입니다.");
			session.setAttribute("InputId", id);
			req.setAttribute("check", check);
		}

		if(word.equals("pwdsearch")) {
			path="/result/pwdSearchOutput.jsp";
		}
		else if(word.equals("idcheck")) {
			path="/result/idcheckOutput.jsp";
		}
		HttpUtil.forward(req, resp, path);
	}

}
