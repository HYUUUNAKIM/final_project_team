package test.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.BoardService;
import test.vo.*;

public class ListSearchController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession();

		BoardService service=BoardService.getInstance();
		String boid1=req.getParameter("boid");
		int boid=Integer.parseInt(boid1);
		Board board=service.boardSearch(boid);
		req.setAttribute("boardli", board);
		HttpUtil.forward(req, resp, "boardView.jsp");
	}

}
