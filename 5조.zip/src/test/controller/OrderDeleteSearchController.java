package test.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.OrdersService;
import test.vo.Orders;

public class OrderDeleteSearchController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=req.getSession();
		
		String id=(String)session.getAttribute("loginID");

		ArrayList<Orders> orderlist=OrdersService.getInstance().orderDeleteSearchList(id);
		req.setAttribute("orderlist", orderlist);
		session.setAttribute("orderlistoutput", orderlist);
		HttpUtil.forward(req, resp, "/result/myOrderDeleteListOutput.jsp");
	}

}
