package test.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.service.MemberService;
import test.vo.Member;

public class MemberListController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Member> list=MemberService.getInstance().memberList();
		req.setAttribute("list", list);
		HttpUtil.forward(req, resp, "/result/memberListOutput.jsp");
	}

}

