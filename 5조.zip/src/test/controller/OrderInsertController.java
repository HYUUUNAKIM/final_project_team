package test.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.OrdersService;
import test.service.ProductService;
import test.vo.*;

public class OrderInsertController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    resp.setContentType("text/html;charset=UTF-8");
	    PrintWriter out=resp.getWriter();
	    HttpSession session=req.getSession();
	    
	    ArrayList<Product> list=(ArrayList<Product>) session.getAttribute("list");
	    int people=Integer.parseInt(req.getParameter("people"));
	    int num=Integer.parseInt(req.getParameter("num"));
	    String id=(String)session.getAttribute("loginID");
	    Product product=list.get(num);
	    String payment = (String)req.getParameter("payment");
	    
	    //out.print(payment);
	    
	    if(product.getPcount()>=people) {
	    int total=product.getPrice()*people;
	    Orders order=new Orders();
	    order.setId(id);
	    order.setPid(product.getPid());
	    order.setOcount(people);
	    order.setTotal(total);
	    order.setPayment(payment);
	    OrdersService service=OrdersService.getInstance();
	    ProductService ser=ProductService.getInstance();
	    service.ordersInsert(order);
	    ser.productCountUpdate(people,product.getPid());
		req.setAttribute("ordersucess", "a");
		HttpUtil.forward(req, resp, "loginMain.jsp");
	    }
	    else {
	    	req.setAttribute("orderfail", "a");
			HttpUtil.forward(req, resp, "loginMain.jsp");
	    }

	}

}
