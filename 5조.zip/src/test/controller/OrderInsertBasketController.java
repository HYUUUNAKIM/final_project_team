package test.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.BasketService;
import test.service.OrdersService;
import test.service.ProductService;
import test.vo.*;

public class OrderInsertBasketController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
	    PrintWriter out=resp.getWriter();
	    HttpSession session=req.getSession();
		ArrayList<Basket> list2=(ArrayList<Basket>)session.getAttribute("basketlist");
		ArrayList<Product> list=(ArrayList<Product>)session.getAttribute("basketproductlist");
		String id=(String)session.getAttribute("loginID");
		String payment = (String)req.getParameter("payment");
		OrdersService service=OrdersService.getInstance();
	    ProductService ser=ProductService.getInstance();
	    BasketService se=BasketService.getInstance();
		
		for(int i=0;i<list.size();i++) {
			Product product=list.get(i);
			Basket basket=list2.get(i);
			if(product.getPcount()>=basket.getOcount()) {
				Orders order=new Orders();
				order.setId(id);
				order.setPid(basket.getPid());
				order.setOcount(basket.getOcount());
				int total=basket.getOcount()*product.getPrice();
				order.setTotal(total);
				order.setPayment(payment);
			    service.ordersInsert(order);
			    ser.productCountUpdate(basket.getOcount(),product.getPid());
			    se.basketDelete(basket.getBid());
			}
			else {
				req.setAttribute("orderfail", "a");
				HttpUtil.forward(req, resp, "loginMain.jsp");
				return;
			}
		}
		req.setAttribute("ordersucess", "a");
		HttpUtil.forward(req, resp, "loginMain.jsp");
	}

}
