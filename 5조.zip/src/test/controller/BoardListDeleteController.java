package test.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.service.BoardService;

public class BoardListDeleteController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String boid1=req.getParameter("boid");
		int boid=Integer.parseInt(boid1);
		
		BoardService service=BoardService.getInstance();
		service.boardDelete(boid);
		HttpUtil.forward(req, resp, "boardSearchlist.do");
	}

}
